var APP_DATA = {
  "scenes": [
    {
      "id": "0-along-engineering-drive-1",
      "name": "Along Engineering Drive 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "yaw": 0.26543855073268574,
        "pitch": 0.0007125718805589543,
        "fov": 1.502645520883113
      },
      "linkHotspots": [
        {
          "yaw": -0.3312305209103066,
          "pitch": -0.43823527680446794,
          "rotation": 7.0685834705770345,
          "target": "1-engineering-auditorium-atrium"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.19603447139164487,
          "pitch": -0.17429502846467138,
          "title": "Faculty of Engineering",
          "text": "Welcome to faculty of engineering"
        }
      ]
    },
    {
      "id": "1-engineering-auditorium-atrium",
      "name": "Engineering Auditorium Atrium",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "yaw": 1.4821385748341065,
        "pitch": 0.1167463680894798,
        "fov": 1.502645520883113
      },
      "linkHotspots": [
        {
          "yaw": 1.8656665579340785,
          "pitch": 0,
          "rotation": 11.780972450961727,
          "target": "0-along-engineering-drive-1"
        },
        {
          "yaw": 1.3253650015153617,
          "pitch": -0.06307789649369333,
          "rotation": 8.63937979737193,
          "target": "2-engineering-auditorium"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-engineering-auditorium",
      "name": "Engineering Auditorium",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1440,
      "initialViewParameters": {
        "yaw": -1.2681117404603768,
        "pitch": -0.23702104757654574,
        "fov": 1.502645520883113
      },
      "linkHotspots": [
        {
          "yaw": -0.939003059226307,
          "pitch": -0.6227721914897195,
          "rotation": 5.497787143782138,
          "target": "1-engineering-auditorium-atrium"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Faculty of Engineering",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
